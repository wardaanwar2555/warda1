#include <iostream>
using namespace std;
class HashTable {
private:
    long size;
    long* table;
    int collisions;

public:
    HashTable(int size) : size(size), collisions(0) {
        table = new long[size];
        for (int i = 0; i < size; ++i) {
            table[i] = -1;
        }
    }

    ~HashTable() {
        delete[] table;
    }

    long hashFunction(long key) {
        long a = 7;      // arbitrarily chosen constant
        long b = 13;     // arbitrarily chosen constant
        long p = 9999991; // a large prime number
        return ((a * key + b) % p) % size;
    }

    void insert(long key) {
        long index = hashFunction(key);
        if (table[index] != -1) {
            collisions++;
            while (table[index] != -1) {
                index = (index + 1) % size;
            }
        }
        table[index] = key;
    }

    int search(long key) {
        long index = hashFunction(key);
        int comparisons = 1;
        while (table[index] != -1 && table[index] != key) {
            index = (index + 1) % size;
            comparisons++;
        }
        return comparisons;
    }

    int getCollisions() {
        return collisions;
    }
};

int main() {
    // Initialize hash table
    int hashTableSize = 9999991;  // Choose a prime number for better distribution
    HashTable hashTable(hashTableSize);

    // Generate and insert 1000 random numbers (you can replace this with your own logic)
    for (int i = 1; i <= 1000; ++i) {
        hashTable.insert(rand() % 1000);  // Replace with your own random number generation logic
    }

    // Perform 100 searches with random numbers (you can replace this with your own logic)
    int totalSearchComparisons = 0;
    for (int i = 1; i <= 100; ++i) {
        totalSearchComparisons += hashTable.search(rand() % 100);  // Replace with your own random number generation logic
    }

    // Display results
    std::cout << "Hash Table Size: " << hashTableSize << std::endl;
    std::cout << "Total Collisions: " << hashTable.getCollisions() << std::endl;

    // Calculate and print the average collisions per insertion
    double averageCollisionsPerInsertion = hashTable.getCollisions() / 1000.0;  // Using 1000.0 to ensure floating-point division
    std::cout << "Average Collisions per Insertion: " << averageCollisionsPerInsertion << std::endl;

    std::cout << "Total Search Comparisons: " << totalSearchComparisons << std::endl;

    system("pause");
    return 0;
}
