#include <iostream>
#include <string>
#include<random>
#include <iomanip>
#include <vector>
using namespace std;
long dummyarr[1000] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56,
57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76,
77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113,
114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129,
130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145,
146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161,
162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187,
188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213,
214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262, 263, 264, 265,
266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291,
292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317,
318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342, 343,
344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369,
370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390, 391, 392, 393, 394, 395,
396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421,
422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447,
448, 449, 450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470, 471, 472, 473,
474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499,
500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525,
526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550, 551,
552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577,
578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598, 599, 600, 601, 602, 603,
604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629,
630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655 ,
 656, 657, 658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678, 679, 680, 681,
    682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706,
    707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731,
    732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756,
    757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781,
    782, 783, 784, 785, 786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806,
    807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831,
    832, 833, 834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854, 855, 856,
    857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881,
    882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902, 903, 904, 905, 906,
    907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931,
    932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956,
    957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981,
    982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998, 999, 1000 };


const long tablesize = 1000;
const long tablesize2 = 1000;
// Node for linked list
struct a {
    long key;
    long value;
    a* next;
};

// Node for binary search tree
struct b {
    long key;
    long value;
    b* left;
    b* right;
};
b* createnode(int k, int v) {
    b* newnode = new b();
    newnode->key = k;
    newnode->value = v;
    newnode->left = nullptr;
    newnode->right = nullptr;
    cout << newnode->key << endl;
    return newnode;

}
// Hash table using array of nodes
a* hashtable1[tablesize];

// Hash table using array of nodes for binary search tree
b* hashtable3[tablesize];
long hashfunction(long key) {
    long a = 7;      // arbitrarily
    long b = 13;
    long p = 9999991; // a large prime number
    return ((a * key + b) % p) % tablesize;
}

// Placeholder node for linear probing hash table
struct node {
    long key;
    long value;
};

// Initialize linear probing hash table
node hashtable[tablesize];

// Initialize table size
void inititailizedtablesize() {
    // Add any initialization code here if needed
}

// Sample hash function: simple modulo operation
long hashfunction2(long key) {
    long a = 7;      // arbitrarily
    long b = 13;
    long p = 9999991; // a large prime number
    return ((a * key + b) % p) % tablesize;
}

// Linear probing hash table insert
void insert(long key[], long value[]) {
    for (int i = 0; i < sizeof(value) / sizeof(value[0]); i++) {
        int collision = 0;
        long index = hashfunction(key[i]);
        cout << "final values " << endl;
        cout << "key " << key[i] << ": " << value[i] << endl;
        //    cout << "index key: " << index << endl;

        while (hashtable[index].key != -1) {
            collision++;
            index = index + 1 % tablesize;  // Corrected line: added parentheses to ensure correct order of operations
        }

        hashtable[index].key = key[i];
        hashtable[index].value = value[i];
        cout << "new value: " << hashtable[index].value << endl;
    }
    for (int i = 0; i < 1000; i++) {
        long index = hashfunction(key[i]);
        hashtable[index].key = key[i];
        cout << "final values " << endl;
        cout << "key " << key[i] << ": " << hashtable[index].value << value[i] << endl;
    }
}




// Linear probing hash table search
// Linear probing hash table search
long search(long key, long value[]) {
    long index = hashfunction(key);
    long comparison = 0;
    while (hashtable[index].key != -1) {
        comparison++;

        if (hashtable[index].key == key) {
            // If the key is found
            std::cout << "Key is found" << std::endl;
            std::cout << "Key: " << hashtable[index].key << ", Value: " << value[key] << ", Collision: " << comparison << std::endl;
            return hashtable[index].value;
        }

        // Linear probing: move to the next index (circular increment)
        index = index + 1 % tablesize;

        // Break the loop if we have checked all slots
        if (index == hashfunction(key)) {
            break;
        }
    }

    // If the key is not found
 //   std::cout << "Key not found in the hash table" << std::endl;
    return -1;
}


void display(long key) {
    long index = hashfunction(key);
    a* temp = hashtable1[index];
    while (temp != nullptr) {
        if (temp->key == key) {
            cout << "Values: " << temp->value << endl;
            return;
        }
        temp = temp->next;
    }

    cout << "Key not found." << endl;
}
// Linked list insert
void insertion(long key[], long value[4]) {
    int collision = 0;

    for (int i = 0; i < 1000; i++) {


        a* newnode = new a{ key[i], value[i], nullptr };

        long index = hashfunction(key[i]);

        if (hashtable1[index] == nullptr) {
            hashtable1[index] = newnode;
        }
        else {
            a* temp = hashtable1[index];
            collision++;

            while (temp->next != nullptr) {
                collision++;
                temp = temp->next;
            }

            temp->next = newnode;
        }

        cout << "Key " << key[i] << " found in linked list at index " << index << "value" << value[i] << "." << endl;

    }


}


// Linked list search
long searching(long key) {
    int comparison = 0;
    long index = hashfunction(key);
    a* temp = hashtable1[index];
    while (temp != nullptr) {
        comparison++;
        if (temp->key == key) {
            std::cout << "THe search at linked index " << index << " with key " << temp->key << "value" << temp->value << std::endl;
            return temp->value;
        }
        temp = temp->next;
    }
    //   cout << "collision during search is: " << comparison << endl;
    return -1;
}

// Remove from linked list

// Helper function for binary search tree insert
void inserthelper(b*& ac, long key, long value[]) {
    long index = hashfunction(key);
    if (ac == nullptr) {
        ac = new b{ key, value[0], nullptr, nullptr };
    }
    else if (key < ac->key) {
        inserthelper(ac->left, key, value);
    }
    else if (key > ac->key) {
        inserthelper(ac->right, key, value);
    }
    else {
        for (int i = 0; i < sizeof(value) / sizeof(value[0]); i++) {
            ac->value = value[i];

        }
    }
    cout << "Key " << key << " found in BST at index " << index << "." << endl;





    return;

}

// Helper function for binary search tree search
b* searchhelper(b*& ac, long key) {
  
    if (ac == nullptr) {
        return nullptr;
    }
    else if (key == ac->key) {
        cout << "Key search in Bst: " << key  << endl;
        return ac;
    }
    else if (key < ac->key) {
        return searchhelper(ac->left, key);
    }
    else {
        cout << "THE value in BST is " << ac->value << " for key " << ac->key << endl;
        return searchhelper(ac->right, key);
    }
    cout << "This won't be reached" << endl;
}


// Binary search tree insert
void insertbst(long key[], long value[]) {

    for (int i = 0; i < 1000; i++) {

        long index = hashfunction(key[i]);

        inserthelper(hashtable3[index], key[i], value);


        cout << "value" << value[i] << endl;
    }
}

// Binary search tree search

long searchbst(long key) {
  
    long index = hashfunction(key);
    if (hashtable3[index] == nullptr) {
        return -1;
    }
    else {

       

        searchhelper(hashtable3[index], key);
       
    }
}

// Find in-order successor in binary search tree
b* inordersuccessor(b* root) {
    while (root->left != nullptr) {
        root = root->left;
    }
    return root;
}

// Remove from binary search tree

// Placeholder for query handling function

int main() {
    // Sample data
    long totalSearchesLinearProbing = 0;
    long totalSearchesLinkedList = 0;
    long totalSearchesBST = 0;
    long data1[1000] = { 67, 71,
           73, 79, 83, 89, 97,2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 101,
           103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167,
           173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269,
           271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379,
           383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487,
           491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607,
           613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727,
           733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853,
           857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977,
           983, 991, 997,  1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051,
1061, 1063, 1069, 1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171,
1181, 1187, 1193, 1201, 1213, 1217, 1223, 1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289,
1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373, 1381, 1399, 1409, 1423, 1427, 1429,
1433, 1439, 1447, 1451, 1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511, 1521, 1523,
1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 1597, 1601, 1607, 1609, 1613, 1619, 1621,
1627, 1637, 1657, 1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 1741, 1747, 1753,
1759, 1777, 1783, 1787, 1789, 1801, 1811, 1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879,
1889, 1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987, 1993, 1997, 1999, 2003, 2011, };

    long data2[1000] = {
        87, 89, 91, 93, 95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115, 117, 119, 121, 123, 125,
        127, 129, 131, 133, 135, 137, 139, 141, 143, 145, 147, 149, 151, 153, 155, 157, 159, 161, 163,
        165, 167, 169, 171, 173, 175, 177, 179, 181, 183, 185, 187, 189, 191, 193, 195, 197, 199, 201,
        1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39,
        41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85,
        203, 205, 207, 209, 211, 213, 215, 217, 219, 221, 223, 225, 227, 229, 231, 233, 235, 237, 239, 241,
        243, 245, 247, 249, 251, 253, 255, 257, 259, 261, 263, 265, 267, 269, 271, 273, 275, 277, 279, 281,
        283, 285, 287, 289, 291, 293, 295, 297, 299, 301, 303, 305, 307, 309, 311, 313, 315, 317, 319, 321,
        323, 325, 327, 329, 331, 333, 335, 337, 339, 341, 343, 345, 347, 349, 351, 353, 355, 357, 359, 361,
        363, 365, 367, 369, 371, 373, 375, 377, 379, 381, 383, 385, 387, 389, 391, 393, 395, 397, 399, 401,
        403, 405, 407, 409, 411, 413, 415, 417, 419, 421, 423, 425, 427, 429, 431, 433, 435, 437, 439, 441,
        443, 445, 447, 449, 451, 453, 455, 457, 459, 461, 463, 465, 467, 469, 471, 473, 475, 477, 479, 481,
        483, 485, 487, 489, 491, 493, 495, 497, 499, 501, 503, 505, 507, 509, 511, 513, 515, 517, 519, 521,
        523, 525, 527, 529, 531, 533, 535, 537, 539, 541, 543, 545, 547, 549, 551, 553, 555, 557, 559, 561,
        563, 565, 567, 569, 571, 573, 575, 577, 579, 581, 583, 585, 587, 589, 591, 593, 595, 597, 599, 601,
        603, 605, 607, 609, 611, 613, 615, 617, 619, 621, 623, 625, 627, 629, 631, 633, 635, 637, 639, 641,
        643, 645, 647, 649, 651, 653, 655, 657, 659, 661, 663, 665, 667, 669, 671, 673, 675, 677, 679, 681,
        683, 685, 687, 689, 691, 693, 695, 697, 699, 701, 703, 705, 707, 709, 711, 713, 715, 717, 719, 721,
        723, 725, 727, 729, 731, 733, 735, 737, 739, 741, 743, 745, 747, 749, 751, 753, 755, 757, 759, 761,
        763, 765, 767, 769, 771, 773, 775, 777, 779, 781, 783, 785, 787, 789, 791, 793, 795, 797, 799, 801,
        803, 805, 807, 809, 811, 813, 815, 817, 819, 821, 823, 825, 827, 829, 831, 833, 835, 837, 839, 841,
        843, 845, 847, 849, 851, 853, 855, 857, 859, 861, 863, 865, 867, 869, 871, 873, 875, 877, 879, 881,
        883, 885, 887, 889, 891, 893, 895, 897, 899, 901, 903, 905, 907, 909, 911, 913, 915, 917, 919, 921,
        923, 925, 927, 929, 931, 933, 935, 937, 939, 941, 943, 945, 947, 949, 951, 953, 955, 957, 959, 961,
        963, 965, 967, 969, 971, 973, 975, 977, 979, 981, 983, 985, 987, 989, 991, 993, 995, 997, 999, 1001,
        1003, 1005, 1007, 1009, 1011, 1013, 1015, 1017, 1019, 1021, 1023, 1025, 1027, 1029, 1031, 1033, 1035,
        1037, 1039, 1041, 1043, 1045, 1047, 1049, 1051, 1053, 1055, 1057, 1059, 1061, 1063, 1065, 1067, 1069,
        1071, 1073, 1075, 1077, 1079, 1081, 1083, 1085, 1087, 1089, 1091, 1093, 1095, 1097, 1099, 1101, 1103
        , 1105, 1107, 1109, 1111, 1113, 1115, 1117, 1119, 1121, 1123, 1125, 1127, 1129, 1131, 1133, 1135, 1137,
        1139, 1141, 1143, 1145, 1147, 1149, 1151, 1153, 1155, 1157, 1159, 1161, 1163, 1165, 1167, 1169, 1171,
        1173, 1175, 1177, 1179, 1181, 1183, 1185, 1187, 1189, 1191, 1193, 1195, 1197, 1199, 1201, 1203, 1205,
        1207, 1209, 1211, 1213, 1215, 1217, 1219, 1221, 1223, 1225, 1227, 1229, 1231, 1233 };


    long data3[1000] = { 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94,
        96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116, 118, 120, 122, 124, 126, 128, 130, 132, 134,
        136, 138, 140, 142, 144, 146, 148, 150, 152, 154, 156, 158, 160, 162, 164, 166, 168, 170, 172, 174,
        2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44,
        46, 48, 50, 52, 54, 56, 58, 60,
        176, 178, 180, 182, 184, 186, 188, 190, 192, 194, 196, 198, 200, 202, 204, 206, 208, 210, 212, 214,
        216, 218, 220, 222, 224, 226, 228, 230, 232, 234, 236, 238, 240, 242, 244, 246, 248, 250, 252, 254,
        256, 258, 260, 262, 264, 266, 268, 270, 272, 274, 276, 278, 280, 282, 284, 286, 288, 290, 292, 294,
        296, 298, 300, 302, 304, 306, 308, 310, 312, 314, 316, 318, 320, 322, 324, 326, 328, 330, 332, 334,
        336, 338, 340, 342, 344, 346, 348, 350, 352, 354, 356, 358, 360, 362, 364, 366, 368, 370, 372, 374,
        376, 378, 380, 382, 384, 386, 388, 390, 392, 394, 396, 398, 400, 402, 404, 406, 408, 410, 412, 414,
        416, 418, 420, 422, 424, 426, 428, 430, 432, 434, 436, 438, 440, 442, 444, 446, 448, 450, 452, 454,
        456, 458, 460, 462, 464, 466, 468, 470, 472, 474, 476, 478, 480, 482, 484, 486, 488, 490, 492, 494,
        496, 498, 500, 502, 504, 506, 508, 510, 512, 514, 516, 518, 520, 522, 524, 526, 528, 530, 532, 534,
        536, 538, 540, 542, 544, 546, 548, 550, 552, 554, 556, 558, 560, 562, 564, 566, 568, 570, 572, 574,
        576, 578, 580, 582, 584, 586, 588, 590, 592, 594, 596, 598, 600, 602, 604, 606, 608, 610, 612, 614,
        616, 618, 620, 622, 624, 626, 628, 630, 632, 634, 636, 638, 640, 642, 644, 646, 648, 650, 652, 654,
        656, 658, 660, 662, 664, 666, 668, 670, 672, 674, 676, 678, 680, 682, 684, 686, 688, 690, 692, 694,
        696, 698, 700, 702, 704, 706, 708, 710, 712, 714, 716, 718, 720, 722, 724, 726, 728, 730, 732, 734,
        736, 738, 740, 742, 744, 746, 748, 750, 752, 754, 756, 758, 760, 762, 764, 766, 768, 770, 772, 774,
        776, 778, 780, 782, 784, 786, 788, 790, 792, 794, 796, 798, 800, 802, 804, 806, 808, 810, 812, 814,
        816, 818, 820, 822, 824, 826, 828, 830, 832, 834, 836, 838, 840, 842, 844, 846, 848, 850, 852, 854,
        856, 858, 860, 862, 864, 866, 868, 870, 872, 874, 876, 878, 880, 882, 884, 886, 888, 890, 892, 894,
        896, 898, 900, 902, 904, 906, 908, 910, 912, 914, 916, 918, 920, 922, 924, 926, 928, 930, 932, 934,
        936, 938, 940, 942, 944, 946, 948, 950, 952, 954, 956, 958, 960, 962, 964, 966, 968, 970, 972, 974,
        976, 978, 980, 982, 984, 986, 988, 990, 992, 994, 996, 998, 1000, 1002, 1004, 1006, 1008, 1010, 1012, 1014, 1016, 1018

    };

    int choice;
    cout << setw(120) << setfill('-') << "" << endl;
    cout << "enter 1 for  data 1 information" << endl;
    cout << "enter 2 for data 2  informtion" << endl;
    cout << "enter 3  for  data 3 for information" << endl;
    cout << setw(120) << setfill('-') << "" << endl;
    cout << "enter choice" << endl;
    cin >> choice;
    switch (choice) {
    case 1:



        insert(dummyarr, data1);
      cout << setw(120) << setfill('-') << "" << endl;
        insertion(dummyarr, data1);
        cout << setw(120) << setfill('-') << "" << endl;
        insertbst(dummyarr, data1);
        cout << setw(120) << setfill('-') << "" << endl;

        


        for (int i = 0; i < 100; ++i) {

            long randomIndex = rand() % 100;  // Assuming 1000 elements in the data1 array
            long  randomKey = data1[randomIndex];// Assuming 100 distinct keys in the hash table



   totalSearchesLinearProbing += search(randomKey, data1);

      totalSearchesLinkedList += searching(randomKey);
            totalSearchesBST += searchbst(randomKey);
        }

        cout << "Linear Probing - Average Searches   of data 1 :" << totalSearchesLinearProbing / 100.0 << endl;
        cout << "Linked List Chaining - Average Searches  data 1: " << totalSearchesLinkedList / 100.0 << endl;
        cout << "BST Chaining - Average Searches   data  1: " << totalSearchesBST / 100.0 << endl;
        break;
    case  2:

        cout << "A" << endl;
        cout << setw(120) << setfill('-') << "" << endl;
        insert(dummyarr, data2);
        cout << "B " << endl;
        cout << setw(120) << setfill('-') << "" << endl;
        insertion(dummyarr, data2);
        insertbst(dummyarr, data2);
        cout << setw(120) << setfill('-') << "" << endl;
        cout << "1" << endl;


        for (int i = 0; i < 100; ++i) {
            long randomindex = rand() % 100;
           
            long randomKey = data2[randomindex];// Assuming 100 distinct keys in the hash table
            totalSearchesLinearProbing += search(randomKey, data2);
            totalSearchesLinkedList += searching(randomKey);
            totalSearchesBST += searchbst(randomKey);
        }

        cout << "Linear Probing - Average Searches   of data2: " << totalSearchesLinearProbing / 100.0 << endl;
        cout << "Linked List Chaining - Average Searches  of data2: " << totalSearchesLinkedList / 100.0 << endl;
        cout << "BST Chaining - Average Searches   data2 : " << totalSearchesBST / 100.0 << endl;
        break;
    case 3:
        cout << setw(120) << setfill('-') << "" << endl;

        insert(dummyarr, data3);
        cout << setw(120) << setfill('-') << "" << endl;
        insertion(dummyarr, data3);
        cout << setw(120) << setfill('-') << "" << endl;
        insertbst(dummyarr, data3);
        cout << setw(120) << setfill('-') << "" << endl;


        for (int i = 0; i < 100; ++i) {

            long randomIndex = rand() % 100;  
            long randomKey = data3[randomIndex];// Assuming 100 distinct keys in the hash table
            totalSearchesLinearProbing += search(randomKey, data3);
            totalSearchesLinkedList += searching(randomKey);
            totalSearchesBST += searchbst(randomKey);
        }

        cout << "Linear Probing - Average Searches  of data 3: " << totalSearchesLinearProbing / 100.0 << endl;
        cout << "Linked List Chaining - Average Searches   of data 3: " << totalSearchesLinkedList / 100.0 << endl;
        cout << "BST Chaining - Average Searches  of data 3: " << totalSearchesBST / 100.0 << endl;
    }



    system("pause");
    return 0;
}
