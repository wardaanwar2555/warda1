#include <iostream>
#include <string>
#include<random>
#include <iomanip>
#include <vector>
using namespace std;
long dummyarr[13] = { 1,2,3,4,5,6,7,8,9,10,11,12,13 };
const long tablesize = 100;
const int TABLE_SIZE = 100;
// Node for linked list
struct a {
    long key;
    long value;
    a* next;
};


struct TreeNode {
    int data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int value) : data(value), left(nullptr), right(nullptr) {}
};

// Node for binary search tree


// Hash table using array of nodes
a* hashtable1[tablesize];

// Hash table using array of nodes for binary search tree
TreeNode* hashtable3[tablesize];

// Placeholder node for linear probing hash table
struct node {
    long key;
    long value;
};

// Initialize linear probing hash table
node hashtable[tablesize];

// Initialize table size


// Sample hash function: simple modulo operation
long hashfunction(long key) {
    long a = 7;      // arbitrarily
    long b = 13;
    long p = 9999991; // a large prime number
    return ((a * key + b) % p) % tablesize;
}

// Linear probing hash table insert
void insert(long key[], long value[]) {


    int collision = 0;

    for (int i = 0; i < 4; i++) {


        long index = hashfunction(key[i]);


        // cout << "index key: " << index << endl;



        while (hashtable[index].key != -1) {
            collision++;
            index = index + 1 % tablesize;
        }


        hashtable[index].key = key[i];



        hashtable[index].value = value[i];
         cout << "new value: " << hashtable[index].value << endl;



    }


    for (int i = 0; i < 13; i++) {

       cout << "final values" << endl;
      cout << "key" << key[i] << ":" << value[i] << endl;
    }





}

void remove(long key) {
    long index = hashfunction(key);
    long originalIndex = index;
    while (true) {
        if (hashtable[index].key == key) {
            cout << "key is deleted" << endl;
            cout << "key: " << hashtable[index].key << "value" << hashtable[index].value << endl;
            hashtable[index].value;

            hashtable[index].key = -2;  // -2 or another special marker indicates a deleted slot
            return;

        }
        index = index + 1 % tablesize;  // Move to the next slot using linear probing
        if (index == originalIndex) {
            // Key not found after a full loop through the table
            break;
        }
    }
    // Key not found in the table
    std::cout << "Key not found in the hash table" << std::endl;
}

// Linear probing hash table search
long search(long key) {

    long index = hashfunction(key);
    //  cout << hashtable[index].value << endl;
    long comparison = 0;

    while (hashtable[index].key != key) {

        comparison++;
        if (hashtable[index].key == -1) {
            cout << "not found" << endl;
            return -1;
        }

        index = index + 1 % tablesize;
    }
    if (hashtable[index].key == key) {
        cout << "key is found" << endl;
        cout << "key: " << hashtable[index].key << "value" << hashtable[index].value << ", collision: " << comparison << endl;
        return hashtable[index].value;
    }

}
void display(long key) {
    long index = hashfunction(key);
    a* temp = hashtable1[index];
    while (temp != nullptr) {
        if (temp->key == key) {
            cout << "Values: " << temp->value << endl;
            return;
        }
        temp = temp->next;
    }

    cout << "Key not found." << endl;
}
// Linked list insert
void insertion(long key[], long value[4]) {
    int collision = 0;

    for (int i = 0; i < 13; i++) {


        a* newnode = new a{ key[i], value[i], nullptr };

        long index = hashfunction(key[i]);

        if (hashtable1[index] == nullptr) {
            hashtable1[index] = newnode;
        }
        else {
            a* temp = hashtable1[index];
            collision++;

            while (temp->next != nullptr) {
                collision++;
                temp = temp->next;
            }

            temp->next = newnode;
        }

        cout << "Key " << key[i] << " found in linked list at index " << index << "value" << value[i] << "." << endl;

    }


}


// Linked list search
long searching(long key) {
    int comparison = 0;
    long index = hashfunction(key);
    a* temp = hashtable1[index];
    while (temp != nullptr) {
        comparison++;
        if (temp->key == key) {
            std::cout << "found at index " << index << " with key " << temp->key << "value" << temp->value << std::endl;
            return temp->value;
        }
        temp = temp->next;
    }
    cout << "collision during search is: " << comparison << endl;
    return -1;
}

// Remove from linked list
long removelinkedlist(long key) {
    long index = hashfunction(key);
    a* head = hashtable1[index];
    a* prev = nullptr;

    while (head != nullptr) {
        if (head->key == key) {
            if (prev == nullptr) {
                hashtable1[index] = head->next;
            }
            else {
                prev->next = head->next;
            }
            int value = head->value;
            cout << "the deleted value" << value << "key" << key << endl;
            delete head;
            return value;
        }
        prev = head;
        head = head->next;
    }

    return -1;
}




// new BST



void insertIntoBST(TreeNode*& root, long value) {
    if (root == nullptr) {
        root = new TreeNode(value);
    }
    else if (value < root->data) {
        insertIntoBST(root->left, value);
    }
    else {
        insertIntoBST(root->right, value);
    }
}

void insertIntoHashTable(TreeNode* hashTable[], long value) {




    int index = hashfunction(value);

    if (hashTable[index] == nullptr) {
        hashTable[index] = new TreeNode(value);
    }
    else {
        //  insertIntoBST(hashTable[index], value);
    }

    cout << "THe value is " << value << endl;

}

// search bst new

bool searchInBST(TreeNode* root, int value) {
    if (root == nullptr) {
        return false;
    }
    else if (root->data == value) {
        cout <<"THe value is" << value << endl;
        return true;
    }
    else if (value < root->data) {
        return searchInBST(root->left, value);
    }
    else {
        return searchInBST(root->right, value);
    }
}

bool searchInHashTable(TreeNode* hashTable[], int value) {
    int index = hashfunction(value);

    if (hashTable[index] == nullptr) {
        return false;
    }
    else {
        return searchInBST(hashTable[index], value);
    }
}


// Helper function for binary search tree search


// Binary search tree insert


// Binary search tree search





// Find in-order successor in binary search tree
TreeNode* inordersuccessor(TreeNode* node) {
    TreeNode* current = node;
    while (current->left != nullptr) {
        current = current->left;
    }
    return current;
}


// Remove from binary search tree
void remover(TreeNode*& ac, long value) {
    if (ac == nullptr) {
        // Node not found
        return;
    }

    if (value < ac->data) {
        // Recursively search in the left subtree
        remover(ac->left, value);
    }
    else if (value > ac->data) {
        // Recursively search in the right subtree
        remover(ac->right, value);
    }
    else {
        // Node with the value found

        if (ac->left == nullptr) {
            // Node has no left child
            TreeNode* temp = ac->right;
            delete ac;
            ac = temp;  // Update the parent pointer
        }
        else if (ac->right == nullptr) {
            // Node has no right child
            TreeNode* temp = ac->left;
            delete ac;
            ac = temp;  // Update the parent pointer
        }
        else {
            // Node has both left and right children
            TreeNode* successor = inordersuccessor(ac->right);
            ac->data = successor->data;
            // Recursively remove the successor node
            remover(ac->right, successor->data);
        }
    }

    // Additional code (for debugging, maybe?)
    if (ac != nullptr) {
        std::cout << "data: " << ac->data << std::endl;
    }
}


// Function to find the in-order successor in the BST


// Remove from binary search tree in hashtable3
void removebst(long key) {
    long index = hashfunction(key);
    remover(hashtable3[index], key);
    cout << "deleted" << key << endl;
}

// Placeholder for query handling function
void queryhandling(string a[]) {
    string kpk = "1";
    string fata = "2";
    string punjab = "3";
    string sindh = "4";
    string balochistan = "5";
    string isb = "6";
    string gilgit = "7";
    
    //(0-Current, 1-Saving, 
    //2 - Salary, 3 - Education, 4 - IT, 5 - Government, 6 - Bonds, 7 - Foreign, 8 - Agriculture, 9 - Ehsas)
    if (a[0] == kpk) {
        cout << a[0] << " khyber pakhtun khaw " << endl;
    }
    else	if (a[0] == fata) {
        cout << a[0] << "fata" << endl;
    }
    else if (a[0] == punjab) {
        cout << punjab << "punjab" << endl;
    }
    else if (a[0] == sindh) {
        cout << "sindh" << sindh << endl;
    }
    else if (a[0] == balochistan) {
        cout << "balochistan" << balochistan << endl;
    }
    else if (a[0] == isb) {
        cout << "isb" << isb << endl;
    }
    else if (a[0] == gilgit) {
        cout << "gilgit" << gilgit << endl;
    }
   
    else {
        cout << "not found" << endl;
    }
    cout << a[1] << "the second digit represent division within province" << endl;
    string b1 = a[2] + a[3] + a[4];
    cout << "it represnt district, tehsil and union council of residence." << b1 << endl;
    cout << "the next seven digit is unique" << endl;
    cout << "The first digit represents the head of the family (father/husband)." << a[5] << endl;
    cout << "The second digit represents the spouse of the head of family (mother/wife)." << a[6] << endl;
    cout << "The third digit represents the eldest child of the family." << a[7] << endl;
    cout << "The fourth digit represents the second eldest child and so on." << a[8] << endl;
    cout << "If more children are born, the additional digits are added at the end to represent new generations."  << a[9] << endl;
    cout << "If more children are born, the additional digits are added at the end to represent new generations." << a[10] + a[11]  << endl;
    cout << "last digit if 13579 then it is male" << endl;
    cout << "last digit 2,4,6,8 female " << endl;
    cout << "last digit" << a[12] << endl;
}

// Custom combination technique for combining two keys
long combineKeys(long key1) {
    // Custom combination technique: multiply the two keys and take modulo of tablesize
    cout  <<key1;

    return key1 % tablesize;
}

// Sample hash function for the first five numbers
long hashFunctionFirstFive(long number) {
    // Sample hash function: simple modulo operation
    return number % 10;  // For demonstration purposes, the hash function simply returns the number modulo 10

}

// Sample hash function for the next seven numbers
long hashFunctionNextSeven(long number) {
    // Another sample hash function: simple modulo operation
    return number % 10;  // For demonstration purposes, the hash function simply returns the number modulo 5
}

// Generate random ID cards and insert into the binary search tree

string generateID() {
    string id = "";
    for (int i = 0; i < 13; i++) {
        int digit = rand() % 10; // Generate a random digit
        id += to_string(digit);  // Append the digit to the ID string
    }
    return id;
}
void storeIDs(vector<string>& hashTable, int tableSize, int& totalCollisions) {
    for (int i = 0; i < 1000; i++) {
        string id = generateID();
        int index = hash<string>{}(id) % tableSize; // Adjust modulo operation if needed
        int collisions = 0;
        while (hashTable[index] != "") {
            collisions++;
            index = (index + 1) % tableSize; // Linear probing
        }
        hashTable[index] = id;
        totalCollisions += collisions;
    }
}
void searchIDs(const vector<string>& hashTable, int tableSize, int& totalComparisons) {

    for (int i = 0; i < 100; i++) {
        string id = generateID();

        int index = hash<string>{}(id) % tableSize;

        int comparisons = 0;
        while (hashTable[index] != id && hashTable[index] != "" && comparisons < tableSize) {
            comparisons++;
            index = (index + 1) % tableSize;
        }


        totalComparisons += comparisons;
    }
}
void reportStatistics(int totalCollisions, int totalComparisons) {

    cout << "Total collisions: " << totalCollisions << endl;
    cout << "Average collisions: " << (double)totalCollisions / 1000 << endl;
    cout << "Total comparisons: " << totalComparisons << endl;
    cout << "Average comparisons: " << (double)totalComparisons / 100 << endl;
}

int main() {
   
    TreeNode* hashTable1[tablesize] = { nullptr };

    long identitycard[100];
    const int tableSize = 1000;
    int totalCollisions = 0, totalComparisons = 0;

    vector<string> hashtable(tableSize);
    // Test linear probing hash table
    cout << setw(120) << setfill('-') << "" << endl;
    cout << "NADRA MANAGEMENT SYSTEM" << endl;
    cout << setw(120) << setfill('-') << "" << endl;
    int choice;
    cout << setw(120) << setfill('-') << "" << endl;
    cout << "enter 1 for  linear probing" << endl;
    cout << "enter 2 for chaining using linked list" << endl;
    cout << "enter 3 for chaining using bst " << endl;
    cout << "enter 4 for random generator" << endl;
    cout << "enter 5 for combining key and display information" << endl;
    cout << setw(120) << setfill('-') << "" << endl;
    cout << "enter your choice" << endl;
    cin >> choice;
    long keyarr[13] = { 1,2,3,4 ,5,6,7,8,9,10,11,12,13};
    switch (choice) {
    case 1:


        for (int i = 0; i < 13; i++) {
            cout << "enter id card number " << endl;
            cin >> identitycard[i];
        }

        cout << "enter id card number " << endl;

        int x;
        cout << "enter 1 for insertion " << endl;
        cout << "enter 2 for searching" << endl;
        cout << "enter 3 for deletion" << endl;
        cout << "enter your choice";
        cin >> x;
        switch (x) {

            // Test linear probing hash table
        case 1:

            insert(keyarr, identitycard);
            //   insert(2, identitycard);
              // insert(1, identitycard);
            break;
        case 2:
            insert(keyarr, identitycard);
            search(3);
            break;
        case 3:
            insert(keyarr, identitycard);



            remove(3);

            break;
        }
    case 2:

        for (int i = 0; i < 13; i++) {
            cout << "enter id card number " << endl;
            cin >> identitycard[i];
        }


        int ak;
        cout << "enter 1 for insertion " << endl;
        cout << "enter 2 for searching" << endl;
        cout << "enter 3 for deletion" << endl;
        cout << "enter your choice";
        cin >> ak;
        switch (ak) {
        case 1:

            insertion(keyarr, identitycard);
            //   insertion(2, identitycard);

            break;
        case 2:
            insertion(keyarr, identitycard);

            searching(3);
            break;
        case 3:
            insertion(keyarr, identitycard);

            removelinkedlist(1);
            break;

        }
    case 3:

        for (int i = 0; i < 13; i++) {
            cout << "enter id card number " << endl;
            cin >> identitycard[i];
        }
        for (int i = 0; i < 13; i++) {
            cout << identitycard[i] << endl;
        }



        int a;
        cout << "enter 1 for insertion " << endl;
        cout << "enter 2 for searching" << endl;
        cout << "enter 3 for deletion" << endl;
        cout << "enter your choice";
        cin >> a;
        switch (a) {
        case 1:



            for (int i = 0; i < 13; ++i) {
                insertIntoHashTable(hashTable1, identitycard[i]);
            }
            //  insertbst(keyarr, identitycard);

            break;
        case 2:

            for (int i = 0; i < 13; ++i) {
                insertIntoHashTable(hashTable1, identitycard[i]);
            }
            if (searchInHashTable(hashTable1, 3)) {
                std::cout << "Search: the  value Found" << std::endl;
            }
            else {
                std::cout << "Search: Not Found"  << std::endl;
            }

            break;
        case 3:


          


            for (int i = 0; i < 13; ++i) {
                insertIntoHashTable(hashTable1, identitycard[i]);
            }
            removebst(3);

            break;
        }
    case 4:




        storeIDs(hashtable, tableSize, totalCollisions);

        searchIDs(hashtable, tableSize, totalComparisons);

        reportStatistics(totalCollisions, totalComparisons);

        break;

    case 5:
        long idcard[13] = { 3,6,5,0,2,5,8,1,4,8,7,2,0 };
        long combinedKey = 1;
        for (int i = 0; i < 5; i++) {
            combinedKey = combineKeys(hashFunctionFirstFive(idcard[i]));

        }

        // Calculate keys for the next seven numbers and combine them
        for (int i = 0; i < 7; i++) {
            combinedKey = combineKeys(hashFunctionNextSeven(idcard[5 + i]));
            //  cout << "Combined Key: " << combinedKey << endl;
        }
        string idnumber[13];
        for (int i = 0; i < 13; i++) {
            cout << "enter id number" << endl;
            cin >> idnumber[i];
        }
        queryhandling(idnumber);
    }

    system("pause");
    return 0;
}