import tkinter as tk
from time import time
import random as r
from PIL import Image, ImageTk

def mistake(partest, usertest):
    error = 0
    for i in range(len(partest)):
        try:
            if partest[i] != usertest[i]:
                error += 1
        except IndexError:
            error += 1
    return error

def speed_time(time_s, time_e, userinput):
    time_delay = time_e - time_s
    if time_delay > 0:
        speed = len(userinput.split()) / time_delay * 60  # Calculate speed in words per minute (WPM)
        return round(speed, 2)
    return 0

def calculate_score(speed, errors, max_speed=100, max_errors=5):
    # Calculate speed score (out of 50)
    speed_score = min((speed / max_speed) * 50, 50)
    # Calculate error score (out of 50)
    error_score = max(0, 50 - (errors / max_errors * 50))  # Reduce score for errors, but not below 0
    # Total score out of 100
    total_score = speed_score + error_score
    return round(total_score, 2)

def start_test():
    global time_1, test1
    test = [
        "Press the keys, let the words flow, and let your thoughts take shape on the page.",
        "With each click-clack, thoughts transform into words, captured forever on the page.",
        "In this world of typed letters, imagination takes flight and dreams become tangible."
    ]
    test1 = r.choice(test)
    text_area.delete(1.0, tk.END)  # Clear previous text
    text_area.insert(tk.END, test1)  # Display the test text
    start_button.config(state=tk.DISABLED)  # Disable start button
    global time_1
    time_1 = time()  # Start timer
    score_label.config(text="")  # Clear previous score

def check_input():
    userinput = text_area.get(1.0, tk.END).strip()
    time_2 = time()  # End timer
    speed = speed_time(time_1, time_2, userinput)
    errors = mistake(test1, userinput)
    score = calculate_score(speed, errors)  # Calculate the score

    # Display results in WPM
    display_results(speed, errors, score)
    start_button.config(state=tk.NORMAL)  # Re-enable start button
    text_area.delete(1.0, tk.END)  # Clear text area
    score_label.config(text=f"Score: {score}/100")  # Display score

def display_results(speed, errors, score):
    result_window = tk.Toplevel(root)
    result_window.title("Typing Test Results")
    result_window.configure(bg='lightblue')

    # Display results in WPM
    result_text = f"Speed: {speed} WPM\nErrors: {errors}\nScore: {score}/100"
    result_label = tk.Label(result_window, text=result_text, bg='lightblue', fg='black', font=('Helvetica', 14, 'bold'))
    result_label.pack(pady=10)

    # Display picture
    img = Image.open("result.jpeg")
   
    photo = ImageTk.PhotoImage(img)
    img_label = tk.Label(result_window, image=photo, bg='lightblue')
    img_label.image = photo  # Keep a reference to avoid garbage collection
    img_label.pack(pady=10)

# Create the main window
root = tk.Tk()
root.title("Typing Speed Test")
root.configure(bg='lightblue')

# Create a text area for typing
text_area = tk.Text(root, height=10, width=50, bg='white', fg='black', font=('Helvetica', 12))
text_area.pack(pady=20)

# Create a button to start the test
start_button = tk.Button(root, text="Start Test", command=start_test, bg='green', fg='white', font=('Helvetica', 14, 'bold'))
start_button.pack(pady=10)

# Create a button to submit the input
submit_button = tk.Button(root, text="Submit", command=check_input, bg='orange', fg='white', font=('Helvetica', 14, 'bold'))
submit_button.pack(pady=10)

# Create a label to display the score
score_label = tk.Label(root, text="", bg='lightblue', fg='black', font=('Helvetica', 14, 'bold'))
score_label.pack(pady=10)

# Run the application
root.mainloop()
