#include<iostream>
#include <conio.h>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;
void Enter() {
    cout << "Press Enter to continue...";
    cin.ignore();
    cin.get();
}
class Item {
private:
    int id;
    string name;
    float price;
public:
    Item() {

    }
    ~Item() {

    }
    void addItem();
    void updateItem();
    void deleteItem();
    void show1() {
        fstream inFile("cart.txt");
        cout << "\t\t\t\t\t\t  ITEMS IN CART\n";
        cout << "\t\t\t----------------------------------------------------------------";
        cout << "\n\t\t\t\t\tID\tName\t\tPrice" << endl;
        cout << "\t\t\t----------------------------------------------------------------";
        while (inFile >> id >> name >> price) {
            cout << "\n\t\t\t\t\t" << id << "-\t" << name << "\t\t" << price;
        }
        cout << "\n\t\t\t----------------------------------------------------------------";

        inFile.close();
    }
    virtual void show() {
        ifstream inFile("items.txt");

        cout << "\n\n\t\t\t\t\tID\tName\t\tPrice" << endl;
        cout << "\t\t\t----------------------------------------------------------------";

        while (inFile >> id >> name >> price) {
            cout << "\n\t\t\t\t\t" << id << "-\t" << name << "\t\t" << price;
        }cout << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        inFile.close();
    }

    void searchItem();
};

void Item::addItem() {
    cout << "\n\n\t\t\t\tEnter Food item ID: ";
    cin >> id;
    cout << "\n\n\t\t\t\tEnter Food item name: ";
    cin.ignore();
    getline(cin, name);
    cout << "\n\n\t\t\t\tEnter Food item price: ";
    cin >> price;


    ofstream outFile("items.txt", ios::app);
    outFile << id << "\t\t" << name << "\t\t" << price << endl;
    outFile.close();

    cout << "Food Item added successfully!" << endl;
}
void Item::updateItem() {
    int itemId;
    bool found = false;

    cout << "\n\n\t\t\t\tEnter Food item ID to update: ";
    cin >> itemId;

    ifstream inFile("items.txt");

    ofstream tempFile("temp.txt");
    // exception handling
    while (inFile >> id >> name >> price) {
        try {
            if (id == itemId) {
                cout << "\n\n\t\t\t\tEnter new Food item name: ";
                cin.ignore();
                getline(cin, name);
                cout << "\n\n\t\t\t\tEnter new Food item price: ";
                cin >> price;
                tempFile << id << "\t" << name << "\t" << price << endl;
                found = true;
                cout << "Food Item updated successfully!" << endl;
                throw id;
            }
        }


        catch (int n) {
            tempFile << id << "\t\t" << name << "\t\t" << price << endl;
        }
    }



    inFile.close();
    tempFile.close();

    if (!found) {
        cout << "Item not found!" << endl;
    }
    else {
        remove("items.txt");
        rename("temp.txt", "items.txt");
    }
}
void Item::deleteItem() {
    int itemId;
    bool found = false;

    cout << "\n\n\t\t\t\tEnter Food item ID to delete: ";
    cin >> itemId;

    ifstream inFile("items.txt");

    ofstream tempFile("temp.txt");

    while (inFile >> id >> name >> price) {

        if (id != itemId) {
            tempFile << id << "\t\t" << name << "\t\t" << price << endl;
            throw id;
        }
        else {
            found = true;
        }

    }

    inFile.close();
    tempFile.close();

    if (!found) {
        cout << "Item not found!" << endl;
    }
    else {
        remove("items.txt");
        rename("temp.txt", "items.txt");
        cout << "Item deleted successfully!" << endl;
    }
}

void Item::searchItem() {
    string itemName;
    bool found = false;

    cout << "\n\n\t\t\t\tEnter FOod item name to search: ";
    cin.ignore();
    getline(cin, itemName);

    ifstream inFile("items.txt");

    while (inFile >> id >> name >> price) {
        if (itemName == name) {
            found = true;
            break;
        }
    }

    inFile.close();

    if (found) {
        cout << "\n\n\t\t\t\tFood Item found:" << endl;
        cout << "\n\n\t\t\t\tID: " << id << endl;
        cout << "\n\n\t\t\t\tName: " << name << endl;
        cout << "\n\n\t\t\t\tPrice: " << price << endl;

    }
    else {
        cout << "Food Item not found." << endl;
    }
}
class Cart {
public:

    void removeItemFromCart();
    void removeItem(int itemID);
    void displayItems();
    void addItemToCart();

private:
    const string CART_FILE = "cart.txt";
    string itemname;
    float itemprice;
};

void Cart::displayItems() {
    std::ifstream file("items.txt"); // Declare and open the file

    if (file.is_open()) {
        std::string item;

        // Read and display the items
        while (std::getline(file, item)) {
            std::cout << item << std::endl;
        }

        file.close(); // Close the file
    }
    else {
        std::cout << "Failed to open the file." << std::endl;
    }
    Enter();
}
void Cart::addItemToCart() {
    bool found = false;
    int itemid;
    int id;
    string name;
    double price;
    cout << "\n\n\t\t\t\tEnter the ID of the Food item to add to Order: ";
    cin >> itemid;
    ifstream inFile("items.txt");
    while (inFile >> id >> name >> price) {
        if (id == itemid) {
            itemname = name;
            itemprice = price;
            found = true;
            break;
        }
    }
    inFile.close();
    if (!found) {
        cout << "Item not found! " << endl;
    }
    else {
        ofstream cartFile("cart.txt", ios::app);
        cartFile << id << "\t\t" << itemname << "\t\t" << itemprice << endl;
        cartFile.close();
        cout << "\t\t\t\t\tItem added to cart successfully! " << endl;
    }
}
void Cart::removeItemFromCart() {
    int itemID;
    bool found = false;
    int id;
    string name;
    double price;
    cout << "\n\n\t\t\t\tEnter the ID of the item to remove from cart: ";
    cin >> itemID;
    ifstream inFile("cart.txt");
    ofstream outFile("temp.txt");
    // Exception handling
    while (inFile >> id >> name >> price) {
        try {
            if (id == itemID) {
                found = true;
                cout << "\n\n\t\tfood Item Removed from cart successfully!" << endl;
                throw id;
            }
        }
        catch (int n) {
            outFile << id << "\t\t" << name << "\t\t" << price << endl;
        }
    }
    inFile.close();
    outFile.close();
    if (!found) {
        cout << "/\n\n\t\tItem not found in the cart !" << endl;
    }
    else {

        remove(CART_FILE.c_str());
        rename("temp.txt", CART_FILE.c_str());
    }


}
void viewCart() {
    Cart cart;

    cout << "\n\t\t\t\t\t\t   ITEMS IN CART" << endl;
    cout << "\t\t\t----------------------------------------------------------------";
    cout << "\n\t\t\t\t\tID\t\tName\t\tPrice" << endl;
    cout << "\t\t\t----------------------------------------------------------------\n";
    cart.displayItems();
}
// function template 
template<typename T>
void login(T username, T userpassword) {

    cout << "Please enter your user name: ";
    cin >> username;
    cout << "Please enter your user password: ";
    cin >> userpassword;

    if (username == "admin" && userpassword == "1234")
    {

        cout << "correct" << endl;

    }
    else
    {
        cout << "Invalid login attempt. Please try again.\n" << '\n';

        login(username, userpassword);
    }

}

class menu1 : public Item, public Cart {
private:
    int choice;
public:
    void display();
};
void menu1::display() {

    do {
        system("cls");
        cout << "              ===================================== Admin Food Menu =====================================              " << endl;
        //cout << setfill('_') << setw(140) << endl << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\n\t\t\t\t1. Add Food item" << endl;
        cout << "\n\n\t\t\t\t2. Update Food item" << endl;
        cout << "\n\n\t\t\t\t3. Delete Food item" << endl;
        cout << "\n\n\t\t\t\t4. Display all Food Items" << endl;
        cout << "\n\n\t\t\t\t5. Go Back  " << endl << endl;
        // cout << setfill('_') << setw(140) << endl << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\n\t\t\t\tEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:system("cls");
            addItem(); Enter();
            break;
        case 2:system("cls"); show();
            updateItem(); Enter();
            break;
        case 3:system("cls");
            deleteItem(); Enter();
            break;
        case 4:system("cls");
            show(); cout << endl; Enter();
            break;
        case 5:system("cls");

            break;
        default:system("cls");
            cout << "Invalid choice!" << endl;
        }

    } while (choice != 5);
}
class Employee {
private:
    int id, age;
    string name;
    float salary;
public:
    void addEmployee();
    void displayEmployee();
    void searchEmployee();
    void updateEmployee();
    void deleteEmployee();
};
void Employee::addEmployee() {
    ofstream outFile("employees.txt", ios::app);

    cout << "\n\t\t\t\tEnter employee ID (integer): ";
    cin >> id;
    if (!id) {
        cout << "Invalid input! Please enter an integer for employee ID: ";
        cin.clear();
        cin.ignore(10000, '\n');
    }

    cout << "\n\t\t\t\tEnter employee name: ";
    cin.ignore();
    getline(cin, name);

    cout << "\n\t\t\t\tEnter employee salary (float): ";
    cin >> salary;
    if (!salary) {
        cout << "Invalid input! Please enter a float for employee salary: ";
        cin.clear();
        cin.ignore(10000, '\n');
    }
    outFile << setw(8) << id << setw(16) << name << setw(8) << salary << endl;

    outFile.close();
}
void Employee::displayEmployee() {
    ifstream inFile("employees.txt");
    cout << "\n\n\t\t\t  ----------------------------- ";

    while (inFile >> id >> name >> salary) {
        cout << "\n\t\t\t\tID: " << id << endl;
        cout << "\t\t\t\tName: " << name << endl;
        cout << "\t\t\t\tSalary: " << salary << endl;
        cout << "\n\t\t\t  ----------------------------- ";
    }cout << endl;

    inFile.close();
}
void Employee::searchEmployee() {
    int empID;
    cout << "Enter the ID of the employee to search: ";
    cin >> empID;

    ifstream infile;
    infile.open("employees.txt", ios::in);

    if (!infile) {
        cout << "Unable to open file!" << endl;
        return;
    }

    Employee e;
    bool found = false;

    while (infile >> e.id >> e.name >> e.salary) {
        if (e.id == empID) {
            found = true;
            break;
        }
    }
    // exception handling
    try {
        if (found) {
            cout << "----------------------------------------" << endl;
            cout << "ID\tName\t\tSalary" << endl;
            cout << "----------------------------------------" << endl;
            cout << e.id << "\t" << e.name << "\t\t" << e.salary << endl;
            throw found;
        }
    }
    catch (bool n)
    {
        cout << "Employee with ID " << empID << " not found." << endl;
    }

    infile.close();
}
void Employee::updateEmployee() {
    int empID;
    cout << "Enter the ID of the employee to update: ";
    cin >> empID;

    fstream file;
    file.open("employees.txt", ios::in | ios::out);

    if (!file) {
        cout << "Unable to open file!" << endl;
        return;
    }

    Employee e;
    bool found = false;

    while (file >> e.id >> e.name >> e.salary) {
        if (e.id == empID) {
            found = true;
            break;
        }
    }
    // exception handling
    try {
        if (found) {
            cout << "----------------------------------------" << endl;
            cout << "ID\tName\t\tSalary" << endl;
            cout << "----------------------------------------" << endl;
            cout << e.id << "\t" << e.name << "\t\t" << e.salary << endl;

            cout << "Enter new name: ";
            cin.ignore();
            getline(cin, e.name);

            cout << "Enter new salary: ";
            cin >> e.salary;

            file.seekp(-1 * (sizeof(Employee)), ios::cur);
            file << e.id << " " << e.name << " " << e.salary;

            cout << "Employee with ID " << empID << " updated successfully." << endl;
        }
        throw found;
    }
    catch (bool n) {
        cout << "Employee with ID " << empID << " not found." << endl;
    }

    file.close();
}
void Employee::deleteEmployee() {
    int deleteId;
    bool found = false;
    ifstream inFile("employees.txt", ios::in);
    ofstream outFile("temp.txt", ios::out);

    cout << "\n\t\t\t\tEnter employee ID to delete: ";
    cin >> deleteId;

    while (inFile >> id >> name >> salary) {
        if (id != deleteId) {
            outFile << id << "\t" << name << "\t" << salary << endl;
        }
        else {
            found = true;
        }
    }
    inFile.close();
    outFile.close();
    try {
        if (found) {
            remove("employees.txt");
            rename("temp.txt", "employees.txt");
            cout << "\n\t\t\t\tEmployee record deleted successfully." << endl;
            throw found;
        }
    }
    catch (bool n) {
        remove("temp.txt");
        cout << "\n\t\t\t\tEmployee record not found." << endl;
    }
}
class menu {
public:
    void diisplay();
};
void menu::diisplay() {
    Employee e;
    int choie = 0;

    do {
        cout << "              ===================================== Admin Employee's Menu =====================================              " << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\t\t\t\t1. Add Employee" << endl;
        cout << "\n\t\t\t\t2. Display Employees" << endl;
        cout << "\n\t\t\t\t3. Update Employees" << endl;
        cout << "\n\t\t\t\t4. Delete Employees" << endl;
        cout << "\n\t\t\t\t5. Return to Main Menu" << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\n\n\t\t\t\tEnter your choice (1-4): ";
        cin >> choie;
        switch (choie) {
        case 1:
            system("cls");
            e.addEmployee();
            break;
        case 2:
            system("cls");
            e.displayEmployee();
            break;
        case 4:system("cls");
            e.deleteEmployee();
            break;
        case 3:
            system("cls");
            e.updateEmployee();
            break;
        default:
            system("cls");
            cout << "Invalid choice!" << endl;
        }
    } while (choie != 5);
}
class index :public Item {
public:
    void show() {
        int choice;
        Item i;
        do {
            system("cls");
            cout << "              ===================================== Food Menu =====================================             " << endl;
            // cout << setfill('_') << setw(140) << endl << endl;          
            i.show();
            cout << "\n\n\t\t\t\t1. Add Dish to Order" << endl;
            cout << "\n\t\t\t\t2. Remove Dish from Order" << endl;
            cout << "\n\t\t\t\t3. View Order" << endl;
            cout << "\n\t\t\t\t4. Back to Main Menu" << endl;
            // cout << setfill('_') << setw(140) << endl << endl;
            cout << "\n\t\t\t----------------------------------------------------------------";
            cout << "\n\n\t\t\t\tEnter your choice: ";
            cin >> choice;
            Cart c;
            switch (choice) {
            case 1:system("cls");
                i.addItem();
                i.show();
                break;
            case 2:system("cls"); i.show1();
                c.removeItemFromCart(); Enter();
                break;
            case 3:system("cls");
                viewCart(); system("cls");// Enter();
                break;
            case 4:system("cls");
                cout << "Going back to main menu..." << endl;
                break;
            default:system("cls");
                cout << "Invalid choice!" << endl;
            }

        } while (choice != 4);
    }
};
void employee() {

    Employee e;
    int choic = 0;
    do {
        cout << "           ===================================== Employee's Menu ===================================== " << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------" << endl;
        cout << " \n\n\t\t\t\t1. Search ID";
        cout << " \n\n\t\t\t\t2. Show all Employees";
        cout << " \n\n\t\t\t\t3. Go Back";
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\n\n\t\t\t\tEnter your choice: ";
        cin >> choic;

        switch (choic) {
        case 1:
            system("cls");
            e.searchEmployee();
            break;
        case 2:
            system("cls");
            e.displayEmployee();
            Enter();
            break;
        case 3:system("cls");
            cout << "Came Back..." << endl;            break;

        default:
            cout << "Invalid Input.!!!" << endl;
        }
    } while (choic != 3);
}

void admin() {
    menu n;
    index m1;
    int choice;
    string a;
    string b;
    login(a, b);
    do {
        system("cls");
        cout << "           ===================================== Admin Menu ===================================== " << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------" << endl;
        cout << " \n\n\t\t\t\t1. Go to Food Items Details";
        cout << " \n\n\t\t\t\t2. Go to Employees Details";
        cout << " \n\n\t\t\t\t3. Go Back";
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\n\n\t\t\t\tEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            system("cls");

            m1.show();
            break;
        case 2:
            system("cls");
            n.diisplay();
            break;
        case 3:system("cls");
            cout << "Came Back..." << endl;
        default:
            cout << "Invalid Input.!!!" << endl;
        }
    } while (choice != 3);

}
int main() {
    menu m1;
    // runtime polymorphism.
    Item* t;
    index i;
    t = &i;
    system("color b");

    int choice; cout << endl << endl << "\t ================================ Welcome to Restaurant Management System ================================ " << endl;
    do {
        // cout << setfill('-') << setw(120);cout << endl << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";
        cout << "\n\t\t\t\t\t\t Main Menu " << endl << endl << endl;
        cout << "\n\t\t\t\t1. Food Menu" << endl;
        cout << "\n\t\t\t\t2. Admin" << endl;
        cout << "\n\t\t\t\t3. Employee" << endl;
        cout << "\n\t\t\t\t4. Exit" << endl;
        //  cout << setfill('_') << setw(139) << endl << endl;
        cout << "\n\n\t\t\t----------------------------------------------------------------";

        cout << "\n\n\n\t\t\t\tEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            system("cls");

            t->show();
            break;
        case 2:
            system("cls");
            admin();
            break;
        case 4:system("cls");
            exit(0);
        case 3:system("cls");
            employee();
            break;
        default:system("cls");
            cout << "Invalid choice!" << endl;
        }
    } while (choice != 4);
    system("pause");
    return 0;
}