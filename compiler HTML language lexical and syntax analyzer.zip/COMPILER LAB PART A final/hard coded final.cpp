#include <iostream>
#include <fstream>
#include <cctype>
using namespace std;
int main() {
	char arr[100];
	int size;

	cout << "Enter size: ";
	cin >> size;
	cin.ignore();

	cout << "Enter line (max " << size << " characters): ";
	cin.getline(arr, sizeof(arr));

	char* chr = arr;
	int i = 0;
	int state = 0;
	while (i < size) {
		if (state == 0) {
			if (chr[i] == '<') {
				cout << chr[i];
				state = 1;
			}
			else if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 9;
			}
			else if (isspace(chr[i])) {
				state = 0;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}

		}
		else if (state == 1) {
			if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 2;
			}
			else if (chr[i] == '/') {
				cout << chr[i];
				state = 7;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
		}
		else if (state == 2) {
			if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 4;

			}
			else	if ( isdigit(chr[i])) {
				cout << chr[i];
				state = 3;
			}
			else if (chr[i] == '>') {
				cout << chr[i];
				state = 5;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}

		}
		else if (state == 3) {
			if (chr[i] == '>') {
				cout << chr[i];
				state = 5;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
		}
		else if (state == 4) {

			if (chr[i] == '>') {
				cout << chr[i];
				state = 5;
			}
			else if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 4;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
		}

		else if (state == 5) {
			if (isspace(chr[i])) {
				cout << chr[i];
				state = 6;
				continue;

			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
		
		}

		else if (state == 6) {
			state = 0;
			cout << ": starting tag without attribute" << chr[i] << endl;
			continue;
		}
		else if (state == 7) {

		 if (isalpha(chr[i]) && islower(chr[i])) {
			cout << chr[i];
			state = 8;
		}
		 else {
			 cout << ": Invalid input at character: " << chr[i] << endl;
			 state = 0;
		 }
		}
		else if (state == 8) {

			if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 15;
			}
			else	if (isdigit(chr[i])) {
				cout << chr[i];
				state = 16;
			}
			else if (chr[i] == '>') {
				cout << chr[i];
				state = 17;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
		}

		


		else if (state == 9) {
			if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 9;
			}
			else	if (chr[i] == '=') {
				cout << chr[i];
				state = 10;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
		}
		else if (state == 10) {
			if (chr[i] == '"') {
				cout << chr[i];
				state = 11;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}

		}
		else if (state == 11) {
			if (isalpha(chr[i]) || isdigit(chr[i]) || chr[i] == '.' || chr[i] == ':' || chr[i] == '\\' || chr[i] == '_') {
				cout << chr[i];
				state = 12;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}

		}
		else if (state == 12) {
			if (isalpha(chr[i]) || isdigit(chr[i]) || chr[i] == '.' || chr[i] == ':'|| chr[i] == '_' || chr[i] == '\\') {
				
				cout << chr[i];
				state = 12;
			}
			else	if (chr[i] == '"') {
				cout << chr[i];
				state = 13;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}


		}
		else if (state == 13) {
			if (isspace(chr[i])) {
				state = 14;

				continue;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}

		}
		else if (state == 14) {
			state = 0;
			cout << ": Attribute" << chr[i] << endl;
			continue;
		}
		else if (state == 15) {
			if (chr[i] == '>') {
				cout << chr[i];
				state = 17;
			}
			else if (isalpha(chr[i]) && islower(chr[i])) {
				cout << chr[i];
				state = 15;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
			}
		else if (state == 16) {
			if (chr[i] == '>') {
				cout << chr[i];
				state = 17;
			}
			else {
				cout << ": Invalid input at character: " << chr[i] << endl;
				state = 0;
			}
			}

		else if (state == 17) {
				if (isspace(chr[i])) {
					cout << chr[i];
					state = 18;
					continue;

				}
				
				}

		

		else if (state == 18) {
					state = 0;
					cout << ": closing tag " << chr[i] << endl;
					continue;
					}
		else {

			cout << "error" << endl;
	}
		i++;
		
	}




	system("pause");
	return 0;
}