#include <iostream>
#include <string>
#include <cctype>
#include <exception>

using namespace std;

char lookahead;
string input;
int index = 0;
bool valid = true;

void match(char t) {
    if (lookahead == t) {
        index++;
        lookahead = index < input.length() ? input[index] : '\0';
    }
    else {
        cout << "Syntax Error: Expected '" << t << "' but found '" << lookahead << "'" << endl;
        exit(1);
    }
}

// Forward declarations
void S();
void T();
void StwA();
void ex();
void pro();
void Property();
void V2();
void valu();
void value();
void j2();
void a1();
void Co();
void startat();
void ct();
void at();
void oo();
void HEADHTML();
void BODY();
void Q();
void G();
void D();
void f();
void h();
void inlineat();
// Main parsing function
void S() {



       ct();
        at();
       G();
        h();



    if (islower(lookahead) && input.find('#') != string::npos && input.find('.') != string::npos) {
        oo();
    }


    else {
        ct();
    }
}
void h() {

    startat();
    Property();
}
void f() {
    HEADHTML();
    ;
    BODY();
}
void G() {
    oo();
    at();
    Q();
    D();

    T();

    value();
}
void valu() {
    if (lookahead == '#') {
        match(lookahead);
        V2();
        V2();
        V2();
        V2();
        V2();
        V2();
    }
}

void T() {
 
    if (islower(lookahead)) {
        at();
        ex();
    }

    Property();

}
void value() {
    if (islower(lookahead)) {
        if (islower(lookahead)) {
            if (islower(lookahead)) {
                ex();
            }

        }
    }
    else {
        valu();
    }
}

void Q() {
    if (lookahead == '<') {
        match('<');
    }
        StwA();
        HEADHTML();
        BODY();
        if (lookahead == '>') {
            match('>');
        }
    
}

void D() {
    if (lookahead == '<') {
        match('<');
    }
    if (lookahead == '/') {
        match('/');


        StwA();
        HEADHTML();

        BODY();

        if (lookahead == '>') {
            match('>');
        }
    }

}



void startat() {
    if (lookahead == '<') {
        match('<');
        if (!islower(lookahead) && !isalpha(lookahead)) {
            valid = false;
            throw runtime_error("Invalid tag start");
        }

        StwA();

        if (lookahead == '=') {
            match('=');
        }
        if (lookahead != '"') {
            valid = false;
            throw runtime_error("Invalid attribute format");
        }
        match('"');
        Co();
        if (lookahead != '"') {
            valid = false;
            throw runtime_error("Missing closing quote");
        }
        match('"');
        if (lookahead != '>') {
            valid = false;
            throw runtime_error("Missing closing bracket");
        }
        if (lookahead == '>') {
            match('>');
        }


    }
}

void ct() {
    if (lookahead == '<') {
        match('<');
        StwA();
    }
    if (lookahead == '>') {
        match('>');
        Co();
    }

    if (lookahead == '<') {
        match('<');
        if (lookahead == '/') {
            match('/');
            StwA();
            match('>');
        }

    }
}

// Helper functions
void StwA() {
    if (islower(lookahead)) {
        match(lookahead);
        if (isdigit(lookahead)) {
            match(lookahead);
        }
        else {
            ex();
        }
    }
}

void ex() {
    if (islower(lookahead)) {
        match(lookahead);
        ex();
    }
}
void at() {
    if (islower(lookahead)) {
        match(lookahead);
        ex();
        if (lookahead == '=') {
            match('=');
            if (lookahead == '"') {
                match('"');
            }
            else {

                cout << "     Expected opening quote for string assignment;";
                valid = false;
            }
         
            inlineat();
           
            a1();
         //   j2();
            if (lookahead == '"') {
                match('"');
            }


            else {

                cout << "     Expected opening quote for string assignment;";
                valid = false;
            }
        }


    }

}


void a1() {
    if (isalpha(lookahead)) {
        match(lookahead);
        a1();
    }
    else if (lookahead == '.' || lookahead == ':' || lookahead == '_' || lookahead == '/') {
        match(lookahead);
        a1();
    }
}

void Co() {
    if (isalpha(lookahead)) {
        match(lookahead);
        Co();
    }
    else if (lookahead == '.' || lookahead == '#' || lookahead == '(' ||
        lookahead == ')' || lookahead == ';' || lookahead == '_' || lookahead == '#' || lookahead == '-' || lookahead == '+' || lookahead == '*' || lookahead == '$' || lookahead == '@' || lookahead == '&' || lookahead == '/' || lookahead == '}' || lookahead == '{' || lookahead == '?') {
        match(lookahead);
        Co();
    }
    else if (isdigit(lookahead)) {
        match(lookahead);
    }
}

void V2() {
    if (isdigit(lookahead) || islower(lookahead)) {
        match(lookahead);
    }
}
void inlineat() {
    Property();
    if (lookahead == ':') {
        match(':');

    }
    value();

}
void Property() {
    ex();
    if (lookahead == '-') {
        match('-');
    }
    ex();
    pro();
}

void pro() {
    if (islower(lookahead)) {
        match(lookahead);
        if (islower(lookahead)) {
            match(lookahead);
            if (islower(lookahead)) {
                match(lookahead);
                if (islower(lookahead)) {
                    match(lookahead);
                    if (islower(lookahead)) {
                        match(lookahead);

                        pro();
                    }
                }
            }
        }
    }
}

void HEADHTML() {
    if (lookahead == 'H') {
        match(lookahead);
        if (lookahead == 'E' || lookahead == 'T') {
            match(lookahead);
            if (lookahead == 'A' || lookahead == 'M') {
                match(lookahead);
                if (lookahead == 'D' || lookahead == 'L') {
                    match(lookahead);
                }
            }
        }
    }
}

void BODY() {
    if (lookahead == 'B') {
        match(lookahead);
        if (lookahead == 'O') {
            match(lookahead);
            if (lookahead == 'D') {
                match(lookahead);
                if (lookahead == 'Y') {
                    match(lookahead);
                }
            }
        }
    }
}

void oo() {
    if (islower(lookahead)) {
        match(lookahead);
        ex();
        if (lookahead == '=') {
            match('=');
            if (lookahead == '"') {
                match('"');
                if (lookahead == '#' || lookahead == '"') {
                    match(lookahead);
                    j2();
                    if (lookahead == '"') {
                        match('"');
                    }
                }
            }
        }
    }
}

void j2() {
    if (isalpha(lookahead)) {
        match(lookahead);
        j2();
    }
    else if (isdigit(lookahead)) {
        match(lookahead);
        j2();
    }
    else if (lookahead == '_') {
        match('_');
        j2();
    }
}

int main() {
    while (true) {
        cout << "Enter input (type 'exit' to quit): ";
        getline(cin, input);

        if (input == "exit") {
            cout << "Exiting program. Goodbye!" << endl;
            break;
        }

        index = 0;
        lookahead = input[0];
        valid = true;

        try {
            S();
            if (lookahead == '\0' && valid) {
                cout << "Parsing Successful!" << endl;
            }
            else {
                cout << "Parsing Failed: Unexpected characters or invalid format!" << endl;
            }
        }
        catch (const runtime_error& e) {
            cout << "Parsing Failed: " << e.what() << endl;
        }
    }
    system("Pause");
    return 0;
}