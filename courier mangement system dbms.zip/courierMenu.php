<!-- for 'courier' navbar, courier placing page -->
<?php


?>
<?php
// Start the session
session_start();

// Set values in the $_SESSION array
$_SESSION['email'] = 'example@example.com';
$_SESSION['u_id'] = 123;

// Include the header file
include('header.php');

// Access the values from the $_SESSION array
$email = $_SESSION['email'];
$uid = $_SESSION['u_id'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Place Order</title>
    <style>
        body {
            background-image: url('../images/1920_1080.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <form action="courierMenu.php" method="POST" enctype="multipart/form-data">
        <div style="overflow-x:auto;">
            <table border="0px solid" style="margin: auto; font-weight:bold;border-spacing: 5px 15px;">
                <th colspan="4" style="text-align: center;background-color:#00FF00; width: 140px; height: 50px;">Fill The Details Of Sender & Receiver</th>
                <tr>
                    <td colspan="4" style="text-align: center;">
                        <hr>
                    </td>
                </tr>
                <tr style="text-align: center;">
                    <th colspan="2">SENDER</th>
                    <th colspan="2">RECEIVER</th>
                </tr>
                <tr>
                    <td colspan="4">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <th colspan="2"></th>
                    <th colspan="2"></th>
                </tr>
                <tr>
                    <td>Name:</td>
                    <td><input type="text" name="sname" placeholder="Sender FullName" required></td>

                    <td>Name:</td>
                    <td><input type="text" name="rname" placeholder="Sender FullName" required></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type="text" name="semail"  placeholder="sender EmailId" required</td>

                    <td>Email:</td>
                    <td><input type="text" name="remail" placeholder="Receiver EmailId" required></td>
                </tr>
                <tr>
                    <td>PhoneNo.:</td>
                    <td><input type="number" name="sphone" placeholder="sender number" required></td>

                    <td>PhoneNo.:</td>
                    <td><input type="number" name="rphone" placeholder="receiver number" required></td>
                </tr>
                <tr>
                    <td>Address:</td>
                    <td><input type="textfield" name="saddress" placeholder="sender address" required></td>

                    <td>Address:</td>
                    <td><input type="textfield" name="raddress" placeholder="receiver address" required></td>
                </tr>
                <tr>
                    <td colspan="4">✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️</td>
                </tr>
                <tr>
                    <td>Weight:</td>
                    <td><input type="number" name="wgt" placeholder="weights in kg" required></td>

                    <td>Payment Id:</td>
                    <td><input type="number" name="billno" placeholder="enter transition num" required></td>
                </tr>
                <tr>
                    <!-- <td>Date:</td><td><input type="date" name="date"></td> -->
                    <td>Date:</td>
                    <td><input type="date" name="date" value="<?php echo date('Y-m-d'); ?>" readonly /></td>
                   
                </tr>
                <tr>
                    <td colspan="4" align="center"><input type="submit" name="submit" value="Place Order" style="background-color: orange; border-radius: 15px; width: 140px; height: 50px;cursor:pointer;"></td>
                </tr>
            </table>
        </div>
    </form>
</body>

</html>
<?php
if (isset($_POST['submit'])) {
    $serverName = "OFFICE"; // Replace with your server name
    $connectionOptions = array(
        "Database" => "courierdb", // Replace with your database name
        "Uid" => "sa", // Replace with your SQL Server username
        "PWD" => "12345" // Replace with your SQL Server password
    );

    // Establishes the connection
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    if ($conn === false) {
        die("Connection failed: " . print_r(sqlsrv_errors(), true));
    }

    $sname = $_POST['sname'];
    $rname = $_POST['rname'];
    $semail = $_POST['semail'];
    $remail = $_POST['remail'];
    $sphone = $_POST['sphone'];
    $rphone = $_POST['rphone'];
    $sadd = $_POST['saddress'];
    $radd = $_POST['raddress'];
    $wgt = $_POST['wgt'];
    $billn = $_POST['billno'];
    $originalDate = $_POST['date'];
    $newDate = date("Y-m-d", strtotime($originalDate));
    $uid = isset($_POST['uid']) ? $_POST['u_id'] : null; // Check if "uid" exists in $_POST
    $query_max_id = "SELECT MAX(c_id) AS max_id FROM courier";
    $result_max_id = sqlsrv_query($conn, $query_max_id);
    $row_max_id = sqlsrv_fetch_array($result_max_id, SQLSRV_FETCH_ASSOC);
    $next_id = $row_max_id['max_id'] + 1;

    $cid = $next_id; // Assigning the next available ID to $cid

    $qry = "INSERT INTO [courier] ([sname], [rname], [semail], [remail], [sphone], [rphone], [saddress], [raddress], [weight], [billno], [date], [u_id],[c_id]) VALUES ('$sname', '$rname', '$semail', '$remail', '$sphone', '$rphone', '$sadd', '$radd', '$wgt', '$billn', '$newDate', '$uid','$cid')";
    $run = sqlsrv_query($conn, $qry);

    if ($run === false) {
        die("Error inserting data: " . print_r(sqlsrv_errors(), true));
    } else {
        ?>
        <script>
            alert('Order Placed Successfully :)');
            window.open('courierMenu.php', '_self');
        </script>
        <?php
    }
}
?>
