-- Set compatibility level to latest (adjust as per your SQL Server version)
-- Table: adlogin
CREATE TABLE adlogin (
  email VARCHAR(50),
  [password] VARCHAR(50),
  a_id INT PRIMARY KEY
);
INSERT INTO adlogin (email, [password], a_id) VALUES ('warda12@gmail.com', '123', 1);
-- Table: admin
CREATE TABLE admin (
  a_id INT PRIMARY KEY,
  email VARCHAR(50) NOT NULL,
  [name] VARCHAR(50),
  pnumber BIGINT
);

-- Table: contacts
CREATE TABLE contacts (
  id INT PRIMARY KEY,
  email VARCHAR(50) NOT NULL,
  [subject] VARCHAR(30) NOT NULL,
  msg VARCHAR(300) NOT NULL
);

-- Table: courier
CREATE TABLE courier (
  c_id INT PRIMARY KEY,
  u_id INT,
  semail VARCHAR(50),
  remail VARCHAR(50),
  sname VARCHAR(50),
  rname VARCHAR(50),
  sphone VARCHAR(20),
  rphone VARCHAR(20),
  saddress VARCHAR(50),
  raddress VARCHAR(50),
  [weight] INT,
  billno INT NOT NULL,
  [date] DATE NOT NULL
);

-- Table: login
CREATE TABLE login (
  email VARCHAR(50) NOT NULL,
  [password] VARCHAR(50) NOT NULL,
  u_id INT PRIMARY KEY
);

-- Table: users
CREATE TABLE users (
  u_id INT PRIMARY KEY,
  email VARCHAR(50) NOT NULL,
  [name] VARCHAR(50),
  pnumber BIGINT
);
INSERT INTO users (u_id, email, [name], pnumber) VALUES (1, 'wardaanwar12@gmail.com', 'warda', 1234567890);

-- Insert data for adlogin

-- for adlogin php
use courierdb 
select * from adlogin;

-- for contactUS php




use courierdb
select * from users;

use courierdb 
select * from courier;

use courierdb
select * from contacts;