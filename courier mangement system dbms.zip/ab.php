<?php
echo "PHP Version: " . phpversion();
?>