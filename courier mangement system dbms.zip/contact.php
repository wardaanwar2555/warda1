
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Information</title>
</head>
<body>
    <h1>Contact Information 1</h1>
    <p><strong>Name:</strong> warda anwar</p>
    <p><strong>Email:</strong> wardaanwar21@gmail.com@example.com</p>
    <p><strong>Phone:</strong> 123-456-7890</p>
    <p><strong>Address:</strong> 123 Main Street, City, Country</p>
	
	    <h1>Contact Information 2</h1>
    <p><strong>Name:</strong> tehmeena zafar</p>
    <p><strong>Email:</strong> tehmeena21@gmail.com@example.com</p>
    <p><strong>Phone:</strong> 123-456-7890</p>
    <p><strong>Address:</strong> 123 Main Street, City, Country</p>
	<img src="exp22.png" alt="Contact Image" style="width: 200px; height: auto;">
</body>
</html>
<?php>

<?