<?php
$serverName = "OFFICE";
$connectionOptions = array(
    "Database" => "courierdb",
    "Uid" => "sa",
    "PWD" => "12345"
);

// Establishes the connection
$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
} else {
    echo "Connected successfully<br>";
}


sqlsrv_close($conn);
 exit; 
?>
