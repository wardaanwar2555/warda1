<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!-- Uncomment the title if needed -->
    <title>Contact Us</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Bootstrap CDN link -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <?php include('header.php'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4 mail-form">
                <h2 class="text-center">Drop a message</h2>
                <p class="text-center">We are waiting for your response..</p>
                
                <form action="contactUs.php" method="POST">
                    <div class="form-group">
                        <input class="form-control" name="email" type="email" placeholder="Email Id" required>
                    </div>
                    <div class="form-group">
                        <input class="form-control" name="subject" type="text" placeholder="Subject" required>
                    </div>
                    <div class="form-group">
                        <!-- Changed to textarea to provide a text area field -->
                        <textarea class="form-control" name="message" placeholder="Compose your message.." required></textarea>
                    </div>
                    <div class="form-group">
                        <input class="form-control button btn-primary" type="submit" name="send" value="Send">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<!-- Starting PHP code -->
<?php
if (isset($_POST['send'])) {
    session_start(); // Initialize session

    $serverName = "OFFICE"; // Replace with your server name
    $connectionOptions = array(
        "Database" => "courierdb", // Replace with your database name
        "Uid" => "sa", // Replace with your SQL Server username
        "PWD" => "12345" // Replace with your SQL Server password
    );

    // Establish the connection
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    if ($conn === false) {
        die("Connection failed: " . print_r(sqlsrv_errors(), true));
    }

    // Access user-entered data
    $eml = $_POST['email'];
    $sub = $_POST['subject'];
    $msg = $_POST['message'];
    
    $qry = "INSERT INTO contacts (email, subject, msg) VALUES (?, ?, ?)";
    $params = array($eml, $sub, $msg);

    $run = sqlsrv_query($conn, $qry, $params);

    if ($run === false) {
        die("Error inserting data: " . print_r(sqlsrv_errors(), true));
    } else {
        ?>
        <script>
            alert('Thanks, we will be looking at your concern :)');
            window.open('home.php', '_self');
        </script>
        <?php
    }

    sqlsrv_close($conn); // Close the database connection
}
?>
