<!-- when track menu is clicked it will show all courier placed by that User-->
<?php
session_start();
if(isset($_SESSION[''])){
    echo "";
    }else{
    header('');
    }

?>


<div style="overflow-x:auto;">
<table width='80%' border="1px dash" style="margin-top:30px;margin-left:auto ;margin-right:auto ;font-weight:bold;border-spacing: 5px 5px;border-collapse: collapse;">
    <tr style="background-color: green;font-size:30px">
        <th>No.</th>
        <th>Item's Image</th>
        <th>Sender Name</th>
        <th>Receiver Name</th>
        <th>Receiver Email</th>
        <th>Action</th>
    </tr>
</div>

  
    <?php 
// Initialize session

$serverName = "OFFICE"; // Replace with your server name
$connectionOptions = array(
    "Database" => "courierdb", // Replace with your database name
    "Uid" => "sa", // Replace with your SQL Server username
    "PWD" => "12345" // Replace with your SQL Server password
);

// Establishes the connection
$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die("Connection failed: " . sqlsrv_errors());
}

// Assuming session_start() is called before accessing $_SESSION variables


// Assuming you already have established a database connection ($conn)
$semail = $_SESSION['semail'] ?? null;
    // Fetching email from session


// Fetching email from session


// Query to fetch data based on session email
$qryy = "SELECT * FROM courier WHERE semail=?";
$params = array($semail);
$options = array("Scrollable" => SQLSRV_CURSOR_KEYSET);
$run = sqlsrv_query($conn, $qryy, $params, $options);


// Checking if query execution was successful
if ($run !== false) {
    // Query to fetch all rows
    $sql = "SELECT sname, rname, remail, c_id, billno FROM courier";

    // Execute the query
    $result = sqlsrv_query($conn, $sql);

    // Checking if query execution was successful
    if ($result !== false) {
?>
<div>
    <table>
        <tr>
            <th>#</th>
            <th>Image</th>
            <th>Sender Name</th>
            <th>Receiver Name</th>
            <th>Receiver Email</th>
            <th>Actions</th>
        </tr>
<?php
        $count = 1; // Initializing count for table rows

        // Fetching data from the database using sqlsrv_fetch_array
        while ($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
?>
        <tr align="center">
            <td><?php echo $count; ?></td>
            <td><img src="track.jpg" alt="pic" style="max-width: 100px;"/> </td>
            <td><?php echo $row['sname']; ?></td>
            <td><?php echo $row['rname']; ?></td>
            <td><?php echo $row['remail']; ?></td>
            <td>
              
               
                <a href="status.php?sidd=<?php echo $row['c_id']; ?>">Check Status</a>
            </td>
        </tr>
<?php
            $count++; // Incrementing count for next row
        }
?>
    </table>
</div>
<?php
    } else {
        // Query execution failed
        echo "Error executing query: " . print_r(sqlsrv_errors(), true);
    }

    // Closing the result set
    sqlsrv_free_stmt($result);
} else {
    // Query execution failed
    echo "Error executing query: " . print_r(sqlsrv_errors(), true);
}

// Closing the database connection
sqlsrv_close($conn);
?>
