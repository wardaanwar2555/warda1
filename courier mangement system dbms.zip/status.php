<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .center-container {
            display: grid;
            place-items: center;
            height: 100vh; /* Full viewport height for vertical centering */
        }
        .center-container img {
            width: 300px; /* Set desired width */
            height: auto; /* Maintain aspect ratio */
        }
    </style>
    <title>Center Image</title>
</head>
<body>
    <div class="center-container">
        <img src="aa.png" alt="Centered Image">
    </div>
</body>
</html>
