<?php

session_start();
if(isset($_SESSION['uid'])){
    echo "";
    }else{
    header('');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style>
        body
        {
        background-image:url('courier-with-parcel-background-delivery-service-van_327176-173.avif');
        background-repeat: no-repeat;
        background-size: cover;
        }
    </style>
</head>
<body>
    <?php include('header.php'); ?>
    <div align='center' style="font-weight: bold;font-family:'Times New Roman', Times, serif"><br><br><br><br>
        <h2>This is a Typhoon Courier Management Service</h2>
        <h4>The fastest courier service</h4><br><br>
        <h3></h3>
        <h6></h6>
    </div>
</body>
</html>