<!-- admin logIn page and login logic -->


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
</head>

<body bgcolor="#067d64">
    <h5><a href="../index.php" style="float: right; margin-right:50px; color:#00BCD4">BackToHome</a></h5><br>
    <h1 align='center' style="color: #00BCD4;font-size:60px">Admin Login</h1>
    <h6 align='center' style="color: #212121;font-weight: bold;font-size:15px">WELCOME</h6>
    <form action="adminlogin.php" method="POST" style="margin: auto;">
        <table align="center">
            <tr>
                <td>Email_ID:</td>
                <td><input type="email" name="uname" require></td>
            </tr>
            <tr><td><br></td></tr>
            <tr>
                <td>Password:</td>
                <td><input type="password" name="pass" require></td>
            </tr>
            <tr>
                <td colspan="2">
                    <hr>
                </td>
            </tr>
            <tr>
                <td colspan="2" align="center"><input type="submit" name="login" value="Login" style="cursor: pointer;"></td>
            </tr>
        </table>
    </form>
</body>

</html>
<?php
session_start(); // Initialize session

$serverName = "OFFICE"; // Replace with your server name
$connectionOptions = array(
    "Database" => "courierdb", // Replace with your database name
    "Uid" => "sa", // Replace with your SQL Server username
    "PWD" => "12345" // Replace with your SQL Server password
);

// Establishes the connection
$conn = sqlsrv_connect($serverName, $connectionOptions);

if ($conn === false) {
    die("Connection failed: " . sqlsrv_errors());
}

// Function to validate user credentials
function validateUser($username, $password, $conn) {
    // Prepare SQL query
    $sql = "SELECT * FROM adlogin WHERE email = ? AND [password] = ?";
    $params = array($username, $password);

    // Execute SQL query
    $stmt = sqlsrv_query($conn, $sql, $params);

    // Check if query execution was successful
    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Fetch the first row from the result set
    $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

    // Free the statement resources
    sqlsrv_free_stmt($stmt);

    return $row; // Return the fetched row
}

// Example usage
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['uname'];
    $password = $_POST['pass'];

    $user = validateUser($username, $password, $conn);

    if ($user) {
        // Set session variables
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        
        // Redirect to home.php upon successful login
        header("Location: home.php");
        exit;
    } else {
        echo "Invalid username or password.";
    }
}

sqlsrv_close($conn); // Close the connection
?>
